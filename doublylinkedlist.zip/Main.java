import java.util.*;
class Node{
    int val;
    Node next;
    Node(int val){
        this.val=val;
        next=null;
    }
}

class Revrse{
    
    public static Node Reverse(Node head){
        Node prev=null;
        Node curr=head;
        Node next=null;
        
        while(curr!=null){
            next=curr.next;
            curr.next=prev;
            prev=curr;
            curr=next;
        }

        return prev;
        
    }
    
}

class Main{
    public static Node insertAt(int pos,int value,Node head)
    {
        Node newNode=new Node(value);
        Node curr=head;
        while(curr!=null){
            if(curr.val==pos){
                newNode.next=curr.next;
                curr.next=newNode;
                break;
            }
                curr=curr.next;
    }
            return head;
    
    }
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        Revrse r=new Revrse();
        int d=sc.nextInt();
        Node head=new Node(d);
        Node curr=head;
        while(true){
            int d1=sc.nextInt();
            if(d1==-1){
                break;
            }
            Node st1=new Node(d1);
            curr.next=st1;
            curr=st1;
        }
        
        curr=head;
        
        while(curr!=null){
            System.out.print(curr.val);
            if(curr.next!=null)
            {
                System.out.print("->");
            }
            curr=curr.next;
        }
        
        curr=head;
        int pos=sc.nextInt();
        int value=sc.nextInt();
        curr=insertAt(pos,value,curr);
        while(curr!=null){
            System.out.print(curr.val);
            if(curr.next!=null)
            {
                System.out.print("->");
            }
            curr=curr.next;
        }
    }
}