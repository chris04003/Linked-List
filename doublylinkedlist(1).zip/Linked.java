import java.util.*;
class Node{
    int val;
    Node next;
    Node prev;
    Node(int val){
        this.val=val;
        next=null;
        prev=null;
    }
}
class Linked{
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        int d=sc.nextInt();
        Node head=new Node(d);
        Node curr=head;
        while(true){
            int d1=sc.nextInt();
            if(d1==-1){
                break;
            }
            Node s1=new Node(d1);
            curr.next=s1;
            s1.prev=curr;
            curr=s1;
        }
        
        curr=head;
        
        
        while(curr!=null){
            System.out.print(curr.val);
            if(curr.next!=null){
                System.out.print("->");
            }
            curr=curr.next;
        }
        
        System.out.println();
        curr=head;
        
        while(curr!=null&&curr.next!=null){
            curr=curr.next;
        }

        while(curr!=null){
            System.out.print(curr.val);
            if(curr.prev!=null){
                System.out.print("->");
            }
            curr=curr.prev;
            
        }
    }
}