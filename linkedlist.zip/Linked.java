import java.util.*;
class Node{
    
    int data;
    Node next;
    
    Node(int data){
        this.data=data;
        next=null;
    }
}


class Linked{
    
    public static Node Reverse(Node head)
    {
       Node prev=null;
       Node curr=head;
       Node next=null;
       
       while(curr!=null){
           
           next=curr.next;
           curr.next=prev;
           prev=curr;
           curr=next;
       }
        
        return prev;
    }
    
   public static void main(String args[]){
       Scanner sc=new Scanner(System.in);
       int d=sc.nextInt();
       Node head=new Node(d);
       Node curr=head;
       while(true){
           int d1=sc.nextInt();
           if(d1==-1){
               break;
           }
               Node n2=new Node(d1);
               curr.next=n2;
               curr=n2;
               
           } 
      
      System.out.println("This is Original Linked list");
       curr=head;
       while(curr!=null){
           System.out.print(curr.data);
           if(curr.next!=null){
               System.out.print("->");
           }
           curr=curr.next;
       }
       
       System.out.println();
       Node prev=Reverse(head);
       
        System.out.println("This is Reverse List:");
       while(prev!=null){
           System.out.print(prev.data);
           if(prev.next!=null){
               System.out.print("->");
           }
           prev=prev.next;
       }
       
   }  
}
