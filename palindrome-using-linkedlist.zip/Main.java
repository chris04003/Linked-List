import java.util.*;
class Node{
    int data;
    Node next;
    Node(int data){
        this.data=data;
        next=null;
    }
}
class Main
{
    public boolean isPalindrome(Node curr1){
        Node slow=curr1;
        Node fast=curr1;
        while(fast!=null&&fast.next!=null){
            slow=slow.next;
            fast=fast.next.next;
        }
        
        Node prev=null;
        Node curr=slow;
        Node next=null;
        
        while(curr!=null){
            next=curr.next;
            curr.next=null;
            prev=curr;
            curr=next;
        }
        
        Node secondhalf=prev;
        Node firsthalf=curr;
        
        while(secondhalf!=null){
            if(secondhalf.data!=firsthalf.data){
                return false;
            }
            
        }
        
        return true;
        
        
        
        
    }
	public static void main(String[] args) {
	   Scanner sc=new Scanner(System.in);
	   int d=sc.nextInt();
	   Node head=new Node(d);
	   Node curr=head;
	   while(true){
	       int d1=sc.nextInt();
	       if(d1==-1){
	           break;
	       }
	       Node n2=new Node(d1);
	       curr.next=n2;
	       curr=n2;
	   }
	   
	   curr=head;
	   while(curr!=null){
	       System.out.print(curr.data);
	       if(curr.next!=null){
	           System.out.print("->");
	       }
	       curr=curr.next;
	       
	   }
	   
	   curr=head;
	    System.out.println(isPalindrome(curr));
	
	   
	
	}
}
	
	
	

