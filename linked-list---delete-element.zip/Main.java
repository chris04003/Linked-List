import java.util.*;
class Node{
    int val;
    Node next;
    Node(int val){
        this.val=val;
        next=null;
    }
}
class Main{
    
    public static Node delete(int vali,Node head){
        Node prev=null;
        Node temp=head;
        if(head.next==null){
            if(head.val==vali){
                head=head.next;
            }
        }
        
        while(temp!=null&&temp.val!=vali){
            prev=temp;
            temp=temp.next;
        }
        
        if(temp==null){
            return head;
        }
        
        prev.next=temp.next;
        
        return head;
    }
    
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        int d=sc.nextInt();
        Node head=new Node(d);
        Node curr=head;
        while(true){
            int d1=sc.nextInt();
            if(d1==-1){
                break;
            }
            Node st1=new Node(d1);
            curr.next=st1;
            curr=st1;
        }
        
        curr=head;
        
         while(curr!=null){
            System.out.print(curr.val);
            if(curr.next!=null){
                System.out.print("->");
            }
            curr=curr.next;
        }
        
        System.out.println();
        
        curr=delete(2,head);
        while(curr!=null){
            System.out.print(curr.val);
            if(curr.next!=null){
                System.out.print("->");
            }
            
            curr=curr.next;
        }
        
        
    }
}